"""Management package for events app."""

