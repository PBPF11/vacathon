"""Management commands for the events app."""

